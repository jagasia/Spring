package com.cts.aj007.spring_demo_1;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.aj007.spring_demo_1.entity.Department;
import com.cts.aj007.spring_demo_1.entity.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
//        Employee employee=new Employee();
//        System.out.println(employee);
        
        //we do not create Employee object. we will get instance from spring ioc container
        //for that first we have to represent the bean.xml as an object
        ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
//        Employee x=(Employee) ctx.getBean("emp1");
//        System.out.println(x);
        	Department d= (Department) ctx.getBean("department");
        	System.out.println(d.getDepartmentId());
        	System.out.println(d.getDepartmentName());
        	List<Employee> employees = d.getEmployees();
        	for(Employee e:employees)
        		System.out.println(e);
    }
}
