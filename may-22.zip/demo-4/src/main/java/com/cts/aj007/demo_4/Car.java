package com.cts.aj007.demo_4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Car {
	private String name;
	private String brand;
	@Autowired
	private Audio pioneer;
	public Car() {}
	public Car(String name, String brand, Audio pioneer) {
		super();
		this.name = name;
		this.brand = brand;
		this.pioneer = pioneer;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public Audio getPioneer() {
		return pioneer;
	}
	public void setPioneer(Audio pioneer) {
		this.pioneer = pioneer;
	}
	@Override
	public String toString() {
		return "Car [name=" + name + ", brand=" + brand + ", pioneer=" + pioneer + "]";
	}
	
}
