package com.cts.aj007.demo_4;

import org.springframework.stereotype.Component;

@Component
public class Sony implements Audio
{
	@Override
	public void play() {
		System.out.println("Sony audio playes music");
		
	}

}
