package com.cts.aj007.demo_4;

public interface Audio {
	public void play();
}
