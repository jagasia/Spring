package com.cts.aj007.demo_4;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.ComponentScan;

@Configurable
@ComponentScan("com.cts")
public class AppConfig {

}
