package com.cts.aj007.demo_4;

import org.springframework.stereotype.Component;

@Component("pioneer")
public class Pioneer implements Audio{

	@Override
	public void play() {
		System.out.println("Pioneer also plays good music");
	}

}
