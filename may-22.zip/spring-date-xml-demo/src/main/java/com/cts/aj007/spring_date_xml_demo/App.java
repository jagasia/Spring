package com.cts.aj007.spring_date_xml_demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.aj007.spring_date_xml_demo.entity.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
        Employee employee=(Employee) ctx.getBean("emp");
        System.out.println(employee);
    }
}
