package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Department;
import com.example.demo.model.Employee;
import com.example.demo.service.DepartmentService;

@RestController
public class DepartmentController {
	@Autowired
	private DepartmentService es;
	
	@PostMapping("/department")
	public Department addDepartment(@RequestBody Department department)
	{
		return es.create(department);
	}
	
	@GetMapping("/department")
	public List<Department> getAllDepartment()
	{
		return es.read();
	}
	
	@GetMapping("/department/{id}")
	public Department findDepartmentById(@PathVariable("id") Long id)
	{
		return es.read(id);
	}
	
	@PutMapping("/department")
	public Department modifyDepartment(@RequestBody Department department)
	{
		return es.update(department);
	}
	
	@DeleteMapping("/department/{id}")
	public void removeDepartment(@PathVariable("id") Long id)
	{
		es.delete(id);
	}
	
	@GetMapping("/department/employees/{id}")
	public List<Employee> getAllEmployeesByDepartment(@PathVariable("id") Long id)
	{
		Department department = findDepartmentById(id);
		return department.getEmployeeList();
	}
}
