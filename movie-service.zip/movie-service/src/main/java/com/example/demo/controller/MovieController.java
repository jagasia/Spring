package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Movie;
import com.example.demo.service.MovieService;

@RestController
@CrossOrigin(origins = {"http://localhost:4200","*"})
public class MovieController {
	@Autowired
	private MovieService ms;
	
	@PostMapping("/movie")
	public Movie addMovie(@RequestBody Movie movie) {
		return ms.create(movie);
	}
	@GetMapping("/movie/{id}")
	public Movie findMovieById(@PathVariable Long id) {
		return ms.read(id);
	}
	@GetMapping("/movie")
	public List<Movie> getAllMovies() {
		return ms.read();
	}
	@PutMapping("/movie")
	public Movie modifyMovie(@RequestBody Movie movie) {
		return ms.update(movie);
	}
	@DeleteMapping("/movie/{id}")
	public void removeMovie(@PathVariable Long id) {
		ms.delete(id);
	}
	@GetMapping("/movie/director/{director}")
	public List<Movie> findMovieByDirector(String director) {
		return ms.findMoviesByDirector(director);
	}
	
}
