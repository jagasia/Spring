package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Movie;
import com.example.demo.repository.MovieRepository;

@Service
public class MovieService {
	@Autowired
	private MovieRepository mr;
	
	public Movie create(Movie movie) {
		return mr.save(movie);
	}
	public List<Movie> read() {
		return mr.findAll();
	}
	public Movie read(Long id) {
		Optional<Movie> result = mr.findById(id);
		if(result!=null)
			return result.get();
		else
			return null;
	}
	public Movie update(Movie movie) {
		return create(movie);
	}
	public void delete(Long id) {
		mr.delete(read(id));
	}
	public List<Movie> findMoviesByDirector(String director)
	{
		return mr.findMoviesByDirector(director);
	}
}
