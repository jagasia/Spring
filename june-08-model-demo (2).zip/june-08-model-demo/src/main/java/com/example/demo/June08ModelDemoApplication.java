package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class June08ModelDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(June08ModelDemoApplication.class, args);
	}

}
