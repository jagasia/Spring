package com.cts.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		System.out.println("Hello world");
		ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
		Bank bank=(Bank) ctx.getBean("bank");
		bank.withdraw();
		bank.deposit();
	}

}
