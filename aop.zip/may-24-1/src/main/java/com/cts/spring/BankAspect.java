package com.cts.spring;

public class BankAspect {

	public void beforeWithdraw()
	{
		System.out.println("Before withdrawing... Doing necessary checks");
	}
	public void afterWithdraw()
	{
		System.out.println("After withdraw.... this method is called");
	}
	
	public void beforeDeposit()
	{
		System.out.println("Before depost");
	}
	public void afterDeposit()
	{
		System.out.println("ASfter deposit");
	}
}
