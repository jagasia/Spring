package com.cts.spring;

public class Bank {
	public void withdraw()
	{
		System.out.println("You are withdrawing amoutn now...");
	}
	public void deposit()
	{
		System.out.println("Deposit method......");
	}
}
