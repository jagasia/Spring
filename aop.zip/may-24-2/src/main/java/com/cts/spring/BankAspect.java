package com.cts.spring;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

@Aspect
@Component
@EnableAspectJAutoProxy
public class BankAspect {

	@Pointcut("execution(* com.cts.spring.*.d*(..))")
	public void deposit()
	{
		
	}
	
	@Pointcut("execution(* com.cts.spring.*.w*(..))")
	public void withdraw()
	{
		
	}
	
	@Before("withdraw()")
	public void beforeWithdraw()
	{
		System.out.println("Before withdrawing... Doing necessary checks");
	}
	@After("withdraw()")
	public void afterWithdraw()
	{
		System.out.println("After withdraw.... this method is called");
	}
	
	@Before("deposit()")
	public void beforeDeposit()
	{
		System.out.println("Before depost");
	}
	@After("deposit()")
	public void afterDeposit()
	{
		System.out.println("ASfter deposit");
	}
}
