package com.cts.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {

	public static void main(String[] args) {
		System.out.println("HElloworld");
		AnnotationConfigApplicationContext ctx=new AnnotationConfigApplicationContext();
		ctx.scan("com.cts");
		ctx.refresh();
		Bank sbi=ctx.getBean(Bank.class);
//		Bank sbi=new Bank();
		sbi.withdraw();
		sbi.deposit();
	}

}
