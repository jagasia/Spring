package com.cts.diagnosticcenter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.diagnosticcenter.service.DiagnosticService;
import com.cts.diagnosticcenter.skeletonvalidator.SkeletonValidator;

public class DianosticCenterApp {

	public static void main(String[] args) {

		SkeletonValidator validator = new SkeletonValidator();
		int ch, noOfTests, age, i;
		double amtPaid;
		String patientName, billData, choice = "yes";
		LocalDate testDate;
		String[] testNames;

		ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
		DiagnosticService diagnosticService = (DiagnosticService) ctx.getBean("diagnosticService");
		do {
			System.out.println("Choose an option :1.Display test charges  2. Display Patient Test Data");
			Scanner sc = new Scanner(System.in);
			ch = sc.nextInt();
			switch (ch) {
			case 1:
				System.out.println("How many tests?");
				noOfTests = sc.nextInt();
				sc.nextLine();
				testNames = new String[noOfTests];

				
				for (i = 0; i < noOfTests; i++) {
					System.out.println("Enter test name " + (i + 1));
					testNames[i] = sc.nextLine();
					if (!diagnosticService.validateTestName(testNames[i]))
						break;
				}
				if (i == noOfTests) {
					System.out.println("Test Details:-");
					Map<String, Double> names = diagnosticService.getTestCharges(testNames);
					for (String s : names.keySet()) {
						System.out.println(s + " " + names.get(s));
					}
					System.out.println(diagnosticService.calculateBill(testNames));
				}
				break;
			case 2:
				System.out.println("Enter Patient Name");
				sc.nextLine();
				patientName = sc.nextLine();
				System.out.println("Enter Age");
				age = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter test Date(dd/MM/yyyy)");
				String tdate = sc.nextLine();

				System.out.println("How many tests?");
				noOfTests = sc.nextInt();
				sc.nextLine();
				testNames = new String[noOfTests];
				for (i = 0; i < noOfTests; i++) {
					System.out.println("Enter test name " + (i + 1));
					testNames[i] = sc.nextLine();
					if (!diagnosticService.validateTestName(testNames[i]))
						break;
				}
				if (i == noOfTests) {
					System.out.println("Enter amount paid ");
					amtPaid = sc.nextDouble();
					DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/MM/yyyy");
					testDate = LocalDate.parse(tdate, df);
					billData = diagnosticService.generateBillData(testNames, testDate, amtPaid);
					String msg = String.format("Name Of Patient:%20s\tAge:%5d\tTestDate:%10s", patientName, age, tdate);
					System.out.println(msg);

					System.out.println(billData);

				}
				break;

			default:
				System.out.println("Invalid Choice");
			}
			System.out.println("Would you like to continue?yes/no");
			choice = sc.next();
		} while (choice.equalsIgnoreCase("yes"));

	}

}
