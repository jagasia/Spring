package com.cts.diagnosticcenter.exception;

public class InvalidTestNameException extends Exception{
	public InvalidTestNameException(String msg)
	{//Insert code here..
		super(msg);
	}

}
