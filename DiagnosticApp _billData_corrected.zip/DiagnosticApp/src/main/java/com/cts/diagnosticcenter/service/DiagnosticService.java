package com.cts.diagnosticcenter.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import com.cts.diagnosticcenter.bo.DiagnosticBo;
import com.cts.diagnosticcenter.exception.InvalidTestNameException;

public class DiagnosticService {

	private DiagnosticBo diagnosticbo;

	public DiagnosticBo getDiagnosticBo() {
		return diagnosticbo;
	}

	public void setDiagnosticBo(DiagnosticBo diagnosticbo) {
		this.diagnosticbo = diagnosticbo;
	}

	public boolean validateTestName(String tname) {
		boolean status = false;
		try {
			diagnosticbo.validateTestName(tname);
			status = true;
		} catch (InvalidTestNameException e) {
			System.out.println(e.getMessage());
			status = false;
		}

		return status;

	}

	public String generateBillData(String[] testNames, LocalDate testDate, double amtPaid) {
		double totalBill = diagnosticbo.calculateBill(testNames);
		double amtLeft = totalBill - amtPaid;
		String reportDate = calculateReportDate(testDate);

		Map<String, Double> map = getTestCharges(testNames);
		String output = "";
		int i = 1;
		for (String testName : testNames) {
			for (String key : map.keySet()) {
				if (testName.equals(key)) {
					output += String.format("%s.%s\t", i++, key);
				}
			}
		}
		/*
		 * return String.format(
		 * "Test Details :%30s\nTotal Bill:%12.1f\t\t\tAmount Paid:%10.1f\t Amount Left:%10.1f\nReport Date :%15s"
		 * , getTestCharges(testNames), totalBill, amtPaid, amtLeft, reportDate);
		 */

		return String.format(
				"Test Details :%30s\nTotal Bill:%12.1f\t\t\tAmount Paid:%10.1f\t Amount Left:%10.1f\nReport Date :%15s",
				output, totalBill, amtPaid, amtLeft, reportDate);

	}

	public String calculateReportDate(LocalDate testDate) {
		LocalDate date = testDate.plusDays(3);
		DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		return date.format(df);
	}

	public Map<String, Double> getTestCharges(String[] testNames) {
		return diagnosticbo.getTestCharges(testNames);

	}

	public String calculateBill(String[] testNames) {
//		String.format("Total Bill :%15.00f",diagnosticbo.calculateBill(testNames));
		return String.format("Total Bill :%15.00f", diagnosticbo.calculateBill(testNames));

	}
}
