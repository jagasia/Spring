package com.cts.diagnosticcenter.model;

import java.util.Map;

public class TestInfo {
	private Map<String,Double> testDetails;

	public Map<String, Double> getTestDetails() {
		return testDetails;
	}

	public void setTestDetails(Map<String, Double> testDetails) {
		this.testDetails = testDetails;
	}
	

}
