package com.cts.diagnosticcenter.bo;

import java.util.Map;
import java.util.TreeMap;

import com.cts.diagnosticcenter.exception.InvalidTestNameException;
import com.cts.diagnosticcenter.model.TestInfo;

public class DiagnosticBo {

	private TestInfo testinfo;

	public TestInfo getTestinfo() {
		return testinfo;
	}

	public void setTestinfo(TestInfo testinfo) {
		this.testinfo = testinfo;
	}

	public void validateTestName(String tname) throws InvalidTestNameException {
		Map<String, Double> tests = testinfo.getTestDetails();
		boolean flag = false;
		for (String s : tests.keySet()) {
			if (tname.equals(s)) {
				flag = true;
				break;
			}
		}
		if (flag == false) {
			throw new InvalidTestNameException("The given test name does not exist!!!");
		}

	}

	public double calculateBill(String[] testNames) {
		double totalBill = 0.0;
		Map<String, Double> tests = testinfo.getTestDetails();
		for (String s : testNames) {
			for (String testName : tests.keySet()) {

				if (s.equals(testName)) {
					totalBill += tests.get(testName);
				}
			}
		}

		return totalBill;
	}

	public Map<String, Double> getTestCharges(String[] testNames) {
		Map<String, Double> testData = new TreeMap<>();
		// Insert code here..

		Map<String, Double> tests = testinfo.getTestDetails();
		for (String s : testNames) {
			for (String testName : tests.keySet()) {

				if (s.equals(testName)) {
					testData.put(testName, tests.get(testName));
				}
			}
		}
		return testData;

	}
}
