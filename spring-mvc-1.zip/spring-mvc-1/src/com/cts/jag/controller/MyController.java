package com.cts.jag.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {

	@RequestMapping("/")
	public String home()
	{
		return "index";				//index is translated using prefix and suffix		/WEB-INF/jsp/index.jsp
	}
	
	@RequestMapping("/contact")
	public String contactUs()
	{
		return "contactus";
	}
}
