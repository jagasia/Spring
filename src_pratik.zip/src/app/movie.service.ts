import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MovieService {
 
  constructor(private http:HttpClient) { }
  

  fnGetAllMovies()
  {
    return this.http.get('http://localhost:8080/movie');
  }

  fnFindMovieById(id)
  {
    return this.http.get('http://localhost:8080/movie/'+id);
  }

  fnFindMovieByDirector(director)
  {
    return this.http.get('http://localhost:8080/movie/director/'+director);
  }

  fnAddMovie(movie)
  {
    return this.http.post('http://localhost:8080/movie',movie);
  }

  fnModifyMovie(movie)
  {
    return this.http.put('http://localhost:8080/movie',movie);
  }

  fnRemoveMovie(id)
  {
    return this.http.delete('http://localhost:8080/movie/'+id);
  }
}
