import { Component, DoCheck, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit, DoCheck {
  movieForm:any;
  movies:any;
  constructor(private fb:FormBuilder, private ms: MovieService) { 
    this.movieForm=this.fb.group({
      id:[],
      name:[],
      language:[],
      director:[]
    });
  }
  ngDoCheck(): void {
    //get all movies
   
  }

  ngOnInit(): void {
    this.ms.fnGetAllMovies().subscribe((data)=>{
      this.movies=data;
    });
  }

  fnFindById()
  {
    var id=this.movieForm.controls['id'].value;
    if(id!='')
    {
      this.ms.fnFindMovieById(id).subscribe((data)=>{
        console.log(data);
        this.movieForm.patchValue(data);
      });
    }
  }
  fnAdd()
  {
    var movie=this.movieForm.value;
    console.log(movie);
    this.ms.fnAddMovie(movie).subscribe((data)=>{
      console.log(data);
    });
  }

  fnModify()
  {
    this.ms.fnModifyMovie(this.movieForm.value).subscribe((data)=>{
      console.log(data);
    });
  }

  fnDelete()
  {
    // alert(this.movieForm.controls['id'].value);
    this.ms.fnRemoveMovie(this.movieForm.controls['id'].value).subscribe((data)=>{
      console.log(data);
    });
  }
}
