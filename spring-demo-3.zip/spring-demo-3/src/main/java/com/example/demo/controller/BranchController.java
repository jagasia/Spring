package com.example.demo.controller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.entity.Branch;

@Controller
@RequestMapping("/branch")
public class BranchController {

	@GetMapping("/")
	public String home()
	{
		//read all branches from db using dao here......and store it in model and display jsp
		return "branch";
	}
	
	@PostMapping("/add")
	public String addBranch(Branch branch)
	{
		return "branch";
	}
}
