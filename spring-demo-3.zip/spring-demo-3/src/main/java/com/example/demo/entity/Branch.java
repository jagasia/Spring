package com.example.demo.entity;

import org.apache.tomcat.util.codec.binary.Base64;

public class Branch {
	private String bid;
	private String bname;
	private String bcity;
	private byte[] pic;
	
	public Branch() {}

	public Branch(String bid, String bname, String bcity) {
		super();
		this.bid = bid;
		this.bname = bname;
		this.bcity = bcity;
	}
	
	

	public Branch(String bid, String bname, String bcity, byte[] pic) {
		super();
		this.bid = bid;
		this.bname = bname;
		this.bcity = bcity;
		this.pic = pic;
	}

	public String getBid() {
		return bid;
	}

	public void setBid(String bid) {
		this.bid = bid;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public String getBcity() {
		return bcity;
	}

	public void setBcity(String bcity) {
		this.bcity = bcity;
	}

	
	
	public byte[] getPic() {
		return pic;
	}
	
	public String getPicture()
	{
		return Base64.encodeBase64String(pic);
	}

	public void setPic(byte[] pic) {
		this.pic = pic;
	}

	@Override
	public String toString() {
		return "Branch [bid=" + bid + ", bname=" + bname + ", bcity=" + bcity + "]";
	}
	
}
