package com.example.demo.exception;

public class DenominatorEightException extends RuntimeException
{
	public DenominatorEightException(String message)
	{
		super(message);
	}
}
