package com.cts.spring;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.cts.spring.dao.BranchDAO;
import com.cts.spring.entity.Branch;

public class App {
	public static void main(String[] args) {
//		DriverManagerDataSource dataSource = new DriverManagerDataSource();
//		dataSource.setDriverClassName("com.mysql.jdbc.Driver");
//		dataSource.setUrl("jdbc:mysql://localhost:3306/bank");
//		dataSource.setUsername("root");
//		dataSource.setPassword("");
//		
//		JdbcTemplate jt=new JdbcTemplate();
//		jt.setDataSource(dataSource);
//		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
//		JdbcTemplate jt=(JdbcTemplate) ctx.getBean("jt");
//		int no=jt.update("INSERT INTO Branch VALUES(?,?,?)","B00058","New Branch","Chennai");
//		System.out.println(no);
		BranchDAO bdao=(BranchDAO) ctx.getBean("bdao");
//		Branch branch=new Branch("B00059", "Another Branch", "Hyderabad"); 
//		int no=bdao.create(branch);
//		System.out.println(no);
		
		
//		List<Branch> branches = bdao.read();
//		for(Branch b : branches)
//			System.out.println(b);
		
		
//		Branch branch = bdao.read("B00059");
//		System.out.println(branch);
		
//		Branch branch=new Branch("B00059", "Another Branch", "Kolkata");		
//		bdao.update(branch);

		bdao.delete("B00059");
		
	}
}
