package com.cts.spring.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.cts.spring.entity.Branch;

public class BranchDAO {
	
	private JdbcTemplate jt;
	
	public BranchDAO() {}
	
	
	public BranchDAO(JdbcTemplate jt) {
		super();
		this.jt = jt;
	}


	public JdbcTemplate getJt() {
		return jt;
	}
	public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}
	public int create(Branch branch)	///add new branch
	{
		String sql="INSERT INTO Branch VALUES(?,?,?)";
		int no;
		return no=jt.update(sql, branch.getBid(), branch.getBname(), branch.getBcity());
	}
	public List<Branch> read()
	{
		String sql="SELECT * FROM Branch";
		return jt.query(sql, new BranchMapper());
	}
	public Branch read(String bid)
	{
		String sql="SELECT * FROM Branch WHERE bid=?";
		return jt.queryForObject(sql, new BranchMapper(), bid);
	}
	public int update(Branch branch)
	{
		String sql="UPDATE Branch SET bname=?, bcity=? WHERE bid=?";
		int no;
		return no=jt.update(sql, branch.getBname(), branch.getBcity(),branch.getBid());
	}
	public int delete(String bid)
	{
		String sql="DELETE FROM Branch WHERE bid=?";
		int no;
		return no=jt.update(sql,bid);
	}
}
