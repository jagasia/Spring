package com.example.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Branch;

@Component("bdao")
public class BranchDao {
	@Autowired
	private JdbcTemplate jt;
	
	@Transactional
	public int create(Branch branch) 
	{
		String sql="INSERT INTO Branch VALUES(?,?,?)";
		return jt.update(sql,branch.getBid(),branch.getBname(),branch.getBcity());
	}
	public List<Branch> read() 
	{
		String sql="SELECT * FROM Branch";
		return jt.query(sql, new BranchRowMapper()); 
	}
	public Branch read(String bid) 
	{
		String sql="SELECT * FROM Branch WHERE bid=?";
		return jt.queryForObject(sql, new BranchRowMapper(), bid);		
	}
	@Transactional
	public int update(Branch branch) 
	{
		String sql="UPDATE Branch SET bname=?, bcity=? WHERE bid=?";
		return jt.update(sql, branch.getBname(), branch.getBcity(), branch.getBid());
	}
	@Transactional
	public int delete(String bid) 
	{
		String sql="DELETE FROM Branch WHERE bid=?";
		return jt.update(sql, bid);
	}
}
