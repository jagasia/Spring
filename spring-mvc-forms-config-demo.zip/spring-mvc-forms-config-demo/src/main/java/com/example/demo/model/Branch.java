package com.example.demo.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class Branch {
	@Pattern(regexp = "B{1}[0-9]{5}", message = "Branch Id must follow B99999 pattern")
	private String bid;
	@Email(message = "Should be like an email id")
	private String bname;
	@Size(min = 1, max=6, message = "City must be atleast 1 character and maximum 6 characters")
	private String bcity;
	
	public Branch() {}

	public Branch(String bid, String bname, String bcity) {
		super();
		this.bid = bid;
		this.bname = bname;
		this.bcity = bcity;
	}

	public String getBid() {
		return bid;
	}

	public void setBid(String bid) {
		this.bid = bid;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public String getBcity() {
		return bcity;
	}

	public void setBcity(String bcity) {
		this.bcity = bcity;
	}

	@Override
	public String toString() {
		return "Branch [bid=" + bid + ", bname=" + bname + ", bcity=" + bcity + "]";
	}
	
	
}
