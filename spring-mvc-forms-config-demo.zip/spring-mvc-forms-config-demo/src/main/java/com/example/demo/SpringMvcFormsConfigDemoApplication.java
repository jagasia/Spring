package com.example.demo;

import javax.sql.DataSource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.example.demo.model.Branch;

@SpringBootApplication

public class SpringMvcFormsConfigDemoApplication {

//	 <bean id="txManager" class= "org.springframework.jdbc.datasource.DataSourceTransactionManager">
//	    <property name="dataSource" ref="dataSource"/>
//	  </bean>

	@Bean
	public DataSourceTransactionManager txManager()
	{
		DataSourceTransactionManager dstm = new DataSourceTransactionManager();
		dstm.setDataSource(dataSource());
		return dstm;
	}
	
	@Bean
	public DataSource dataSource()
	{
		DriverManagerDataSource dmds=new DriverManagerDataSource();
		dmds.setDriverClassName("com.mysql.jdbc.Driver");
		dmds.setUrl("jdbc:mysql://localhost:3306/bank");
		dmds.setUsername("root");
		dmds.setPassword("");
		return dmds;
	}
	
	@Bean
	public ViewResolver configureViewResolver()
	{
		InternalResourceViewResolver vr = new InternalResourceViewResolver();
		vr.setPrefix("/WEB-INF/jsp/");
		vr.setSuffix(".jsp");
		return vr;
	}

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcFormsConfigDemoApplication.class, args);
	}
}
