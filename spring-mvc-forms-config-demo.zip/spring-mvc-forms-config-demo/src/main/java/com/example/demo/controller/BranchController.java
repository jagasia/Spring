package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.dao.BranchDao;
import com.example.demo.model.Branch;

@Controller
public class BranchController {

	@Autowired
	private BranchDao bdao;
	
	@GetMapping("/")
	public String home(ModelMap model)
	{
		model.addAttribute("branch", new Branch());
		List<Branch> branches = bdao.read();
		model.addAttribute("branches", branches);
		return "branch";
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "dml", params = "add")
	public String addBranch(@Valid Branch branch,  BindingResult br, ModelMap model)
	{
		
		System.out.println(br.hasErrors());
		if(br.hasErrors())
		{
			List<Branch> branches = bdao.read();
			model.addAttribute("branches", branches);
			model.addAttribute("branch", branch);
			return "branch";
		}
		model.addAttribute("branch", branch);
		List<Branch> branches = bdao.read();
		model.addAttribute("branches", branches);
		System.out.println("Adding "+branch);
		int status = bdao.create(branch);
		System.out.println(status+" row(s) inserted");
		return select(branch.getBid(), model);
	}
	@RequestMapping(method = RequestMethod.POST, value = "dml", params = "modify")
	public String modifyBranch(Branch branch, ModelMap model)
	{
		int status=bdao.update(branch);
		System.out.println(status+" row(s) affected");
		return select(branch.getBid(), model);
	}
	@RequestMapping(method = RequestMethod.POST, value = "dml", params = "delete")
	public String deleteBranch(Branch branch, ModelMap model)
	{
		int status=bdao.delete(branch.getBid());
		System.out.println(status+" row(s) deleted");
		return home(model);
	}
	
	@GetMapping("/select")
	public String select(@RequestParam("bid") String bid, ModelMap model)
	{
		Branch branch = bdao.read(bid);
		System.out.println("Found branch for "+bid);
		System.out.println(branch);
		if(branch==null)
			branch=new Branch();
		model.addAttribute("branch",branch);
		List<Branch> branches = bdao.read();
		model.addAttribute("branches", branches);
		return "branch";
	}
	
}
